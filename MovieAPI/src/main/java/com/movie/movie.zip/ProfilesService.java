package com.movie.service;

import com.movie.dto.ProfilesDto;
import com.movie.model.Profiles;
import com.movie.repository.ProfilesRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.NoSuchElementException;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class ProfilesService {

    private final ProfilesRepository profilesRepository;

    public ProfilesService(ProfilesRepository profilesRepository){
        this.profilesRepository = profilesRepository;
    }

    public ProfilesDto getProfilesById(Long id) {
        Optional<Profiles> profilesOptional = this.profilesRepository.findById(id);
        Profiles profiles = profilesOptional.orElseThrow(() -> new NoSuchElementException("Profile not found"));
        return ProfilesDto.convert(profiles);
    }

    // 모든 프로필 가져오기 메서드 추가
    public List<ProfilesDto> getAllProfiles() {
        List<Profiles> profilesList = this.profilesRepository.findAll();
        return profilesList.stream().map(ProfilesDto::convert).collect(Collectors.toList());
    }
}

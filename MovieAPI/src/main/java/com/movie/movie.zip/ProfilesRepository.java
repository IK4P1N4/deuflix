package com.movie.repository;


import com.movie.model.Profiles;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface ProfilesRepository extends JpaRepository<Profiles, Long> {

    // Profiles를 id로 찾기
    Optional<Profiles> findById(Long id);
}

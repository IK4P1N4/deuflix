package com.movie.dto

import com.movie.model.Profiles
import com.movie.model.User

data class ProfilesDto @JvmOverloads constructor(
        val id: Long?,
        val u_id: User?,
        val p_name: String?,
) {
    companion object {
        @JvmStatic
        fun convert(from: Profiles): ProfilesDto {
            return ProfilesDto(
                    from.id,
                    from.user,
                    from.name
            )
        }
    }
}

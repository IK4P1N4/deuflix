package com.movie.controller;

import com.movie.dto.ProfilesDto;
import com.movie.service.ProfilesService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api/v1/profiles")
public class ProfilesController {

    private final ProfilesService profilesService;

    public ProfilesController(ProfilesService profilesService) {
        this.profilesService = profilesService;
    }

    @Operation(summary = "Get Profiles By Id")
    @GetMapping("/{id}")
    public ResponseEntity<ProfilesDto> getProfilesById(@Parameter(description = "id of Profiles to be searched") @PathVariable Long id) {
        return ResponseEntity.ok(this.profilesService.getProfilesById(id));
    }

    // 모든 프로필 가져오기 엔드포인트 추가
    @Operation(summary = "Get All Profiles")
    @GetMapping
    public ResponseEntity<List<ProfilesDto>> getAllProfiles() {
        return ResponseEntity.ok(this.profilesService.getAllProfiles());
    }

}
